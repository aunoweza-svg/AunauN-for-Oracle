---
name: herdr-wt
description: Create an isolated Git worktree and optional Herdr workspace for an explicitly
  assigned task. Use for new work that needs its own branch; does not spawn an agent
  automatically.
---

# herdr-wt — PRISM / Codex

This is the PRISM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Read project instructions and resolve the target Git common directory, main checkout and current branch/status. Define goal, scope and done criteria in a durable local brief or an issue if requested. Verify the base ref and remote before using it; a repository with no commits cannot create a normal worktree, and a missing origin is not permission to invent one. Choose an unused readable branch/path and use git worktree add without replacing existing paths. Check installed herdr worktree help before opening an associated workspace. Keep the caller focus and report actual branch/path/IDs. Use the current Codex agent unless the user asks to delegate; do not use bypass flags. Do not commit, push or merge as a side effect of creation.
