---
name: ui-ux-pro-max
description: Design and review UI/UX using the installed local style, palette, typography,
  accessibility and stack databases. Use for visual/interface work; skip non-visual
  backend tasks.
---

# ui-ux-pro-max — PRISM / Codex

This is the PRISM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Read the target product, users, existing design system and actual stack. Resolve this skill directory from the loaded SKILL.md path. Run python3 <absolute-skill-directory>/scripts/search.py with a focused query: --design-system for a new system, --domain for a targeted concern, --stack for implementation. Scripts and data are bundled locally and use Python standard library. Check results match the requested domain before applying them. Persist only when requested, passing an explicit --output-dir and preserving existing MASTER.md. Verify responsive layout, keyboard access, semantics, loading/error states and visual output.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
