---
name: tdd
description: Implement a feature or bug fix with meaningful test-first red/green cycles
  when test-first work is requested. Test public behavior, not private implementation
  details.
---

# tdd — PRISM / Codex

This is the PRISM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Identify the user-visible behavior and the existing test boundary from the task and repository. Use already established scope without asking for seam approval again; clarify only if the missing contract materially changes behavior. Write one test that fails for the actual missing behavior, implement the minimal change, then repeat in vertical slices. Avoid tautological tests, private-method assertions and mocks that merely mirror implementation. Run relevant checks and refactor with tests green. No mandatory unavailable codebase-design tool or vendor-specific agent call.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
