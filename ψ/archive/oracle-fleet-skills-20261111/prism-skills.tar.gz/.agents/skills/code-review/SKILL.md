---
name: code-review
description: Review a diff for concrete correctness issues and adherence to the task
  and repository standards. Use for PRs, branches or working changes; keep standards
  and requirements findings distinct.
---

# code-review — PRISM / Codex

This is the PRISM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Determine the intended diff from the user and live Git state. Validate the comparison ref; use working-tree/staged diff when that is the task rather than forcing HEAD-only review. Read relevant standards and spec/issue if available; missing spec can be reported, not a mandatory setup blocker. Review both standards and requested behavior in the current agent; delegate only when the user requested parallel review or applicable instructions require it. Report actionable file/line findings, severity, reason and meaningful validation. Separate definite defects from subjective suggestions. Do not edit code, post comments or merge unless requested.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
