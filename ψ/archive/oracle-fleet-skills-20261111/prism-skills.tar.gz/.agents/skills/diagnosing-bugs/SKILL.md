---
name: diagnosing-bugs
description: Diagnose bugs or performance regressions by reproducing the exact symptom,
  narrowing causes and verifying the fix. Use for broken, failing or unexpectedly
  slow behavior.
---

# diagnosing-bugs — PRISM / Codex

This is the PRISM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Read the relevant code, logs and project conventions. Establish a small repeatable check of the user-visible symptom; if the environment is unavailable, distinguish observed evidence from hypotheses and state what cannot be reproduced. Minimize the repro, test falsifiable hypotheses and change one cause at a time. Add a meaningful regression test at a boundary that catches the actual defect when warranted. Re-run the original symptom and remove temporary instrumentation before delivery. Do not require arbitrary hypothesis counts, hidden agents or production instrumentation without authorization.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
