---
name: herdr-pr
description: Prepare or add a factual Built by attribution block to an authorized
  PR, issue or comment. Use for traceable authorship; it does not replace a PR description
  or automatically publish a comment.
---

# herdr-pr — PRISM / Codex

This is the PRISM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Verify the actual repository, branch, commit and producing session. When Herdr is used, follow the herdr skill and resolve the live caller rather than shell focus. Include Oracle, exact model only if known, work reference and a verified reply route. Do not invent model/session identity. Public or unknown visibility omits private transcript paths, memory paths, sockets and environment. A Built by block is attribution, not a cryptographic signature. Prepare text locally first; post only when opening/updating that PR/comment is authorized. Missing remote/PR is an honest limitation, not permission to create infrastructure. Never merge.
