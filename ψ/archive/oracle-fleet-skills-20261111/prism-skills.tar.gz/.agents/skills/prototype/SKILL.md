---
name: prototype
description: Build a runnable throwaway prototype to answer a UI or logic/state-model
  question. Use for validating an approach before production implementation.
---

# prototype — PRISM / Codex

This is the PRISM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Choose the question first: logic/state behavior uses LOGIC.md; visual alternatives use UI.md. Make it trivial to run, clearly mark it as a prototype, expose relevant state and avoid unnecessary persistence/abstractions. Do not overwrite production or demand a new branch/issue for every small prototype. Capture the validated finding and artifact path; commit or publish only when that is part of the user task.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
