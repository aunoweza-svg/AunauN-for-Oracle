# AXIOM finance runtime (WSL)

Run Python through `tools/finance/python <script.py>` or `tools/finance/python -c '...'` from the AXIOM repo. The launcher resolves its own environment and does not change the system Python or global PATH.

The local `.venv` contains yfinance, numpy, pandas, scipy and matplotlib. It is ignored by Git and must be recreated after cloning to a new machine. `requirements.lock.txt` records installed package versions; it does not include credentials.

Installation uses a separately verified uv binary, then `uv venv --python /usr/bin/python3 tools/finance/.venv` and `uv pip install --python tools/finance/.venv/bin/python -r tools/finance/requirements.lock.txt`. Choose a task-specific writable cache directory if the host cache is protected. Do not install into system Python to work around a missing environment.

This runtime only supplies analysis dependencies. Data availability, freshness, exchange coverage and provider terms still require validation per request. No account, wallet, order or transfer capability is enabled.
