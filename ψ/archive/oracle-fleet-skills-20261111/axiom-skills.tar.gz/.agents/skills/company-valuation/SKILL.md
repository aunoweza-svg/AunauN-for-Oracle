---
name: company-valuation
description: Build evidence-backed DCF, comparable-company or SOTP valuations with
  explicit assumptions, sensitivity and scenarios. Use for intrinsic value questions;
  never promise a target price outcome.
---

# company-valuation — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Use the isolated finance Python launcher for data/model calculations. Source statements and share/debt/cash values with consistent dates, units and currency. Separate observed data from forecasts; make discount-rate, growth, margins, capital needs and terminal assumptions explicit. Check EV-to-equity bridges and sensitivity; preserve missing data rather than filling it as fact. Use the local DCF/WACC/relative/SOTP references as methods, not fixed US-market defaults. No personalized recommendation or transaction from a model result alone.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
