---
name: earnings-recap
description: Analyze reported earnings with actual-versus-consensus comparisons, operating
  trends and price reaction. Use for released results, distinguishing facts from interpretation.
---

# earnings-recap — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Identify the exact reporting period and publication time, then favor issuer releases/filings for actual results. Use tools/finance/python for supporting data. Compare matching GAAP/non-GAAP measures, currencies, periods and pre-release consensus. Separate reported results, guidance and price reaction windows; show arithmetic and missing data. Do not label price movement as caused by one factor without evidence.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
