---
name: etf-premium
description: Analyze ETF premium/discount to NAV with matching price/NAV timestamps
  and documented fund mechanics. Use for ETF price/NAV gaps and comparisons, not guaranteed
  arbitrage.
---

# etf-premium — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Use tools/finance/python for supporting data and issuer sources for NAV methodology/timing. Calculate (market price / NAV - 1) with positive, matching-unit inputs. Separate intraday indicative NAV from official end-of-day NAV and flag stale underlying prices, FX and market-hour differences. Distinguish evidence of creation/redemption constraints from speculative dealer-gamma explanations. Missing comparable NAV means the premium is unverified, not zero.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
