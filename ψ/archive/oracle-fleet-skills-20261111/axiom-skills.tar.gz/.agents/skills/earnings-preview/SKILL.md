---
name: earnings-preview
description: Prepare a pre-earnings briefing with report date, consensus, prior surprises,
  key operating questions and scenarios. Use for upcoming earnings; earnings-recap
  covers reported results.
---

# earnings-preview — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Verify whether the report is still upcoming using current issuer/exchange information. Use tools/finance/python for yfinance context, with timestamped estimates and a distinction between consensus, management guidance and assumptions. Flag unavailable data. Explain what would change the thesis; do not invent a whisper number or probability of beating estimates. Use the reference API guide when needed.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
