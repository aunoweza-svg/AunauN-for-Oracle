---
name: stock-liquidity
description: Assess stock liquidity using public spread, volume, turnover and clearly
  labeled execution-cost estimates. Use for tradability research; public snapshots
  are not a full live order book.
---

# stock-liquidity — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Use tools/finance/python and timestamp the source. Compute matched-period volume/dollar-volume and spreads with explicit units and zero/missing handling. Distinguish top-of-book snapshots, historical proxies and modeled market impact; do not infer depth or executable fills from Yahoo volume alone. Explain that impact/slippage models are assumptions rather than verified trading costs. No order or account actions.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
