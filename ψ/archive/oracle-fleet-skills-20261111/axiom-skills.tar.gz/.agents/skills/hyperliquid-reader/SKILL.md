---
name: hyperliquid-reader
description: Read public Hyperliquid mids, order books, candles and funding data without
  wallet/account access. Use for Hyperliquid market research only; no orders, transfers
  or account reads.
---

# hyperliquid-reader — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Use the bundled scripts/public_info.py adapter for supported read-only queries: mids, book, candles, funding or meta. It POSTs a fixed allowlisted request to the public /info endpoint and needs no wallet or API key. Run --help for bounded parameters. Preserve source, retrieval time and funding interval; annualized funding is a comparison convention, not promised yield. For multi-venue comparisons use additional verified public sources only when requested. The upstream opencli route is optional, not a dependency of this adaptation.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
