#!/usr/bin/env python3
"""Public market-only Hyperliquid info client. No wallet, account or trade requests."""
import argparse
from datetime import datetime, timezone
import json
import re
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ENDPOINT='https://api.hyperliquid.xyz/info'
INTERVALS={'1m':60000,'3m':180000,'5m':300000,'15m':900000,'30m':1800000,
           '1h':3600000,'2h':7200000,'4h':14400000,'8h':28800000,'12h':43200000,
           '1d':86400000,'3d':259200000,'1w':604800000}


def request_body(mode,coin,interval='1h',limit=100,hours=24,now_ms=None):
    if not re.fullmatch(r'[A-Za-z0-9@._/-]{1,40}',coin):raise ValueError('Invalid public market symbol')
    now=int(time.time()*1000) if now_ms is None else now_ms
    if mode=='mids':return {'type':'allMids'}
    if mode=='meta':return {'type':'metaAndAssetCtxs'}
    if mode=='book':return {'type':'l2Book','coin':coin}
    if mode=='funding':
        if not 1<=hours<=168:raise ValueError('hours must be 1..168')
        return {'type':'fundingHistory','coin':coin,'startTime':now-hours*3600000,'endTime':now}
    if mode=='candles':
        if interval not in INTERVALS or not 1<=limit<=5000:raise ValueError('Invalid candle interval/limit')
        return {'type':'candleSnapshot','req':{'coin':coin,'interval':interval,
                'startTime':now-limit*INTERVALS[interval],'endTime':now}}
    raise ValueError('Unsupported market-data request')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['mids','meta','book','candles','funding'])
    parser.add_argument('--coin',default='BTC');parser.add_argument('--interval',choices=INTERVALS,default='1h')
    parser.add_argument('--limit',type=int,default=100);parser.add_argument('--hours',type=int,default=24)
    parser.add_argument('--depth',type=int,choices=range(1,21),default=5)
    parser.add_argument('--request-only',action='store_true')
    args=parser.parse_args()
    try:
        body=request_body(args.mode,args.coin,args.interval,args.limit,args.hours)
        if args.request_only:
            print(json.dumps({'endpoint':ENDPOINT,'request':body}));return 0
        req=Request(ENDPOINT,data=json.dumps(body).encode(),method='POST',headers={
            'Content-Type':'application/json','User-Agent':'AXIOM-Oracle/1.0 public-market-data'})
        with urlopen(req,timeout=25) as response:data=json.load(response)
        if args.mode=='mids':data={args.coin:data.get(args.coin)}
        elif args.mode=='book':data=dict(data,levels=[side[:args.depth] for side in data.get('levels',[])])
        elif args.mode in ['candles','funding']:data=data[-args.limit:]
        print(json.dumps({'source':ENDPOINT,'retrieved_at':datetime.now(timezone.utc).isoformat(),
                          'request':body,'data':data},ensure_ascii=False))
        return 0
    except (ValueError,HTTPError,URLError,TimeoutError,OSError) as exc:
        print(json.dumps({'error':type(exc).__name__,'message':str(exc),'source':ENDPOINT}));return 2


if __name__=='__main__':sys.exit(main())
