---
name: yfinance-data
description: Fetch public market data and statements using the isolated AXIOM yfinance
  environment. Use for a specified ticker/data request; distinguish vendor data, timestamps
  and missing fields.
---

# yfinance-data — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Use tools/finance/python, the AXIOM-local launcher, for Python scripts. It must point to tools/finance/.venv; do not pip-install globally. Confirm ticker/exchange, period, interval, currency and timezone. Fetch only requested fields and retain source/retrieval time. Yahoo data can be delayed, stale, incomplete or restricted: validate critical claims against issuer/exchange sources. A ticker alone does not authorize portfolio access or trading. Consult references/api_reference.md for calls.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
