---
name: sepa-strategy
description: Study stocks through the SEPA trend template, base/pattern hypotheses
  and risk-based sizing. Use when SEPA, VCP or trend-following analysis is requested;
  no trade execution.
---

# sepa-strategy — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Apply local trend/stage/fundamental/pattern references to timestamped evidence. Use tools/finance/python for available data. Separate objective trend conditions from subjective chart patterns and missing inputs. Position sizing requires the user-specified capital, risk and stop assumptions; otherwise show a hypothetical formula clearly labeled. Do not treat historical strategy claims or model scores as verified returns for the user.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
