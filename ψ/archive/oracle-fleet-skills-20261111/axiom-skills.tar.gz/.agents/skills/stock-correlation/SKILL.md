---
name: stock-correlation
description: Measure stock return correlation, beta, rolling relationships and comparison
  groups from aligned price histories. Use for co-movement and diversification research,
  not guaranteed hedges.
---

# stock-correlation — AXIOM / Codex

This is the AXIOM repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Use tools/finance/python with matching calendars, currencies, periods and adjusted-price treatment. Correlate returns, not raw price levels; handle missing observations and report sample size/window. Explain selection bias, unstable regimes and the distinction between correlation and causation. Compare rolling windows when useful and keep model assumptions explicit. Use the sector-universe reference as a starting set, not proof of current membership.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
