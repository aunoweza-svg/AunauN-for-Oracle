#!/usr/bin/env python3
"""Run a bundled ffmpeg-skill script with Lumina's local FFmpeg on PATH."""
import os
from pathlib import Path
import re
import subprocess
import sys


def main():
    if len(sys.argv)<2:
        print('Usage: python3 tools/media.py <probe|fit|cut|look|_contract|...> [arguments]',file=sys.stderr);return 2
    name=sys.argv[1].removesuffix('.py')
    if not re.fullmatch(r'[a-z_][a-z0-9_]*',name):
        print('Select a bundled script basename, not a path',file=sys.stderr);return 2
    root=Path(__file__).resolve().parent.parent
    script=root/'.agents/skills/ffmpeg-skill/scripts'/f'{name}.py'
    if not script.is_file():
        print('Bundled media script not found: '+name,file=sys.stderr);return 2
    binaries=root/'tools/ffmpeg/bin'
    if not all((binaries/x).is_file() for x in ['ffmpeg','ffprobe']):
        print('Lumina WSL FFmpeg runtime is missing; see tools/ffmpeg-WSL.md',file=sys.stderr);return 2
    child_env=os.environ.copy();child_env['PATH']=str(binaries)+os.pathsep+child_env.get('PATH','')
    fonts=root/'tools/fonts/fonts.conf'
    if fonts.is_file():child_env['FONTCONFIG_FILE']=str(fonts)
    return subprocess.run([sys.executable,str(script),*sys.argv[2:]],env=child_env).returncode


if __name__=='__main__':sys.exit(main())
