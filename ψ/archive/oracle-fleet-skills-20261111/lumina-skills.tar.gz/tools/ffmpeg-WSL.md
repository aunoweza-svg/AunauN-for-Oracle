# Lumina WSL FFmpeg

`python3 tools/media.py <script-name> ...` runs the existing ffmpeg-skill scripts using binaries at `tools/ffmpeg/bin/`. The PATH change belongs only to that subprocess; the Windows runtime and global shell config are unchanged.

The Linux build is downloaded from FFmpeg-Builds/FFmpeg-Builds (the successor URL redirected from BtbN), with the release API asset SHA-256 verified before extraction. Provenance is in local `tools/ffmpeg/source.json` and the fleet installation report. Binary files and generated test media are not intended for Git publication; retain the accompanying license when redistributing a build.

After cloning, restore the documented build or a compatible current Linux FFmpeg and ffprobe into this bin directory, then run `python3 tools/media.py _contract doctor --json`. Machine/platform details and optional tools such as transcription models can differ. A successful basic render does not prove every optional capability.
