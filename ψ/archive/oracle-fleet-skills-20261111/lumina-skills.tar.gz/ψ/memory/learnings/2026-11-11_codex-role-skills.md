# Lumina — Codex skills verified 2026-11-11

ติดตั้ง/ปรับชุดที่ผู้ใช้อนุญาตสำหรับ Codex/WSL แล้ว รวมชุดบทบาท 17 ตัว

พื้นฐาน 11 ตัว: `rrr`, `forward`, `learn`, `trace`, `where-we-are`, `herdr`, `herdr-whoami`, `herdr-neighbors`, `herdr-peek`, `herdr-hey`, `herdr-structure`

เฉพาะงาน: `content-strategy`, `social`, `copywriting`, `ad-creative`, `video`, `ffmpeg-skill`

เรียก `python3 tools/media.py _contract doctor --json` และ `python3 tools/media.py <script> ...`; launcher ใช้ FFmpeg/ffprobe portable และ Noto Sans Thai ภายใน repo โดยไม่เปลี่ยน PATH ถาวร สกิล FFmpeg ถูกค้นพบด้วยชื่อ `ffmpeg-skill:ffmpeg-skill`; `imagegen` ใช้ของระบบที่มีอยู่แล้ว

## ความจำและ Git

เมื่อผู้ใช้เรียก `/rrr` ให้บันทึกใน repo และความจำของตัวเองเป็นค่าเริ่มต้น ทั้งสาม repo ลูกยังไม่มี origin ณ วันที่ตรวจ ไม่ยืม remote หรือสิทธิ์ auto-push ของ repo AunauN หากจะเผยแพร่ต้องมีคำสั่งและตรวจปลายทางก่อน

รักษาตัวตนเดิม ไม่เรียก awaken ใหม่ ไม่สร้าง agent เพิ่มอัตโนมัติ และไม่เปลี่ยนคำสั่งติดตั้งให้เป็นสิทธิ์เผยแพร่/ซื้อขาย

## หลักฐานและข้อจำกัด

Native Codex app-server skills/list ตรวจ cwd ของ repo นี้แล้ว: required 17, repo-local 17, enabled รวมระบบ 22, discovery errors 0; ตรวจ frontmatter และ supporting files ตาม install manifest ผ่าน

ทดสอบเครื่องมือจริงใน fleet: UI search, การคำนวณ/กราฟการเงิน, Yahoo Finance, Hyperliquid public mids และวิดีโอ H.264/AAC พร้อมซับไทยผ่าน ตรวจภาพเรนเดอร์แล้ว คำแนะนำที่เป็น workflow ไม่ได้หมายความว่าได้ทำแคมเปญจริง สร้าง issue/PR จริง หรือทำ valuation บริษัทครบกระบวนการแล้ว

รายงานรวมอยู่ใน repo AunauN: ψ/lab/oracle-fleet-skills-20261111/REPORT.md พร้อม discovery, hashes, backups และผลทดสอบ Windows skills ต้นทางไม่ถูกแก้

เปิด session ใหม่ใน repo นี้หาก session ปัจจุบันยังไม่แสดงสกิล แล้วเรียกชื่อเช่น `$learn`, `$trace`, `$rrr` หรือชื่อสกิลเฉพาะงานตาม host ที่ใช้งาน
