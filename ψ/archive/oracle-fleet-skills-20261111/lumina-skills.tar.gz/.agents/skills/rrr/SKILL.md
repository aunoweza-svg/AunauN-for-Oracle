---
name: rrr
description: Write a retrospective, lessons and metrics when asked for /rrr, $rrr or a session retrospective. Use this Oracle’s own repo policy; publication is not automatic. Discussing installation or testing rrr does not request publication of the real workspace.
---

# RRR — Codex / LUMINA

Read applicable AGENTS.md and CLAUDE.md; resolve the active Git root and real ψ directory before writing. A nested Oracle repo is a separate target. Preserve the existing identity.

## Evidence and artifacts

Execute synchronously by default. `--fg` uses current context and Git only, without persisted transcripts. `--light` writes metadata, timeline, summary, lessons and metrics. `--fg`, `--bg`, `--combo` are mutually exclusive. For background modes detect real host capabilities and session attribution first; fall back explicitly to synchronous writing if unavailable. Do not launch hidden agents or assume Claude paths or models.

Use Asia/Bangkok time. Use only observed host/session metadata and attributable Git times. Commit times describe those commits; current time is a closing time, not proof of a start. Unknown start, duration and session ID stay `unknown`. Never interpolate idle gaps or manufacture mistakes.

Write a unique `ψ/memory/retrospectives/YYYY-MM/DD/HH.MM_<slug>.md` using [template.md](references/template.md). Add a transferable lesson under `ψ/memory/learnings/YYYY-MM-DD_<slug>.md` when justified. Append exactly one row to `ψ/memory/learnings/session-metrics.md`, preserving all other rows and line endings. Columns: `when | session | done | stuck | win | friction | error`. Review the last seven rows for recurring friction without opening an issue automatically.

## This Oracle repository

Save under this Oracle's own resolved ψ. As verified during installation, this repository has no origin remote and no local user rule authorizing automatic GitHub sync. Default rrr saves the retrospective, lesson and metrics locally. Do not borrow the parent AunauN repository's auto-push rule or destination, and do not add a remote, stage, commit or push solely because rrr was invoked. If the user explicitly requests publication later, verify that repository's destination and scope first. A future explicit local AGENTS.md sync policy can replace this default.

When commit/push is explicitly authorized, inspect shared staging and use an explicit file/hunk allowlist, [the metrics helper](scripts/stage-metrics-row.py), and a temporary index if unrelated work is staged. Preserve other rows/files; never force push, merge a PR or disclose private research. Verify the actual remote before reporting publication.
