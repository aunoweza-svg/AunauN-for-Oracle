---
name: social
description: Draft and adapt social posts, short-video hooks, scripts, carousels and
  platform calendars. Use for Facebook, Instagram, TikTok or other named social content;
  scheduling/publication requires a separate authorized action.
---

# social — LUMINA / Codex

This is the LUMINA repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Start from audience, campaign goal, platform, supplied facts and CTA. Draft usable copy or a timed script, with asset requirements and variants only when useful. For short video specify hook, beats, voice, on-screen text and action; for carousels specify slide purpose. Verify changing platform limits before final export. Treat upstream algorithm/performance claims as dated guidance. Never invent testimonials, locations, availability or measured results.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
