---
name: copywriting
description: Write or improve tourism marketing copy, headlines, landing pages, offers
  and calls to action using supportable claims. Use for persuasive wording; retain
  AI attribution required by the project.
---

# copywriting — LUMINA / Codex

This is the LUMINA repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Clarify audience, offer, desired action, proof and objections from the supplied context. Write in the requested Thai/brand voice with concrete benefits and a clear next action. Support factual and comparative claims with evidence; label proposed wording when facts are missing. Do not fabricate testimonials, scarcity, guarantees or human authorship. Consult local copy frameworks and editing references for the chosen format.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
