---
name: content-strategy
description: Plan content themes, audiences, editorial calendars and distribution
  for a tourism brand or campaign. Use for what to create and why; social handles
  individual platform pieces.
---

# content-strategy — LUMINA / Codex

This is the LUMINA repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Use the campaign brief to map audience needs and journey to content pillars, formats, channels and calendar. Separate current facts from creative concepts and unsupported claims. Give each proposed piece a purpose, audience, evidence needs, CTA and evaluation metric. Scale the plan to available production capacity. Preserve the brand voice and Lumina identity from CLAUDE.md; no account publishing or scheduling without authorization.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
