---
name: ad-creative
description: Create campaign ad concepts, hooks, copy variations, storyboards and
  production briefs. Use for paid-ad creative; installing this skill does not authorize
  ad spend or publication.
---

# ad-creative — LUMINA / Codex

This is the LUMINA repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Connect each concept to an audience insight, offer, proof and measurable creative hypothesis. Deliver the requested headlines/copy or shot-by-shot brief with dimensions, duration, CTA and asset needs. Check current placement requirements before rendering. Distinguish dramatization and AI-generated media from actual customer evidence; no fabricated endorsements. Route production to the available image/video tool or ffmpeg-skill, preserving the campaign facts.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
