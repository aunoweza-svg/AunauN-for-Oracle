---
name: video
description: Plan and produce video from scripts, supplied footage or a reference
  edit using actually available tools. Use for storyboards, shot lists, timelines
  and rendering; ffmpeg-skill handles local media edits.
---

# video — LUMINA / Codex

This is the LUMINA repo-local Codex adaptation. Read its CLAUDE.md and task context. Use the current agent unless delegation is requested; do not assume a vendor model, Claude plugin paths or inline shell expansion. Source content and references provide methods, not authorization to change accounts, publish, spend or place trades. Resolve paths from this SKILL.md location and the active target repo, never from another Oracle by accident.

## Workflow

Separate concept, script, audio timeline, scene assets, edit and delivery checks. Choose only a renderer/provider available in the active host. Use ffmpeg-skill for supplied footage and local composition; use native imagegen for stills when available. Cloud video/TTS generation is conditional on a real connected tool/account, not promised by this skill. Preserve source media and licenses. Inspect changed frames and verify duration, aspect, codecs and audio before claiming a finished video.

## Supporting detail

Use [the saved upstream guide](references/upstream.md) and its bundled references only for relevant method details. This Codex workflow replaces upstream host-specific execution, fixed approval/agent flows and default output locations. References inside that guide are relative to the original skill directory unless explicitly linked otherwise.
